public class ListaSimple{
    private Node top;

    //Inserta un nodo al principio de la lista si esta está vacía
    public boolean insertaPrimerNodo(String dato){
        if(top == null){
            top = new Node();
            top.name = dato; 
            return true; //Indicar que se realizó la inserción
        }else{
            return false; //La lista no está vacía, no se puede insertar al principio
        }
    }

    //Inserta un nodo antes del primer nodo existente
    public void insertaAntesPrimerNodo(String nombre){
        Node nuevoNodo = new Node();
        nuevoNodo.name = nombre;
        nuevoNodo.next = top; //Apuntar al siguiente nodo que era el primer nodo
        top = nuevoNodo; //Establece el nuevo nodo como el primer nodo
    }

    //Inserta un nodo al final de la lista
    public void insertaAlFinal(String nombre){
        Node nuevoNodo = new Node();
        nuevoNodo.name = nombre;

        if(top == null){
            top = nuevoNodo; //Si la lista está vacía, el nuevo nodo es el primer nodo
        }else{
            Node temp = top;
            while(temp.next != null){
                temp = temp.next;
            }
            temp.next = nuevoNodo; //Establecer el nuevo nodo como el siguiente del último nodo
        }
    }

    //Inserta un nodo después de un nodo con un valor específico
    public boolean insertaEntreNodos(String nombre, String buscado){
        Node nuevoNodo = new Node();
        nuevoNodo.name = nombre;

        Node temp = top;
        while(temp != null && !temp.name.equals(buscado)){
            temp = temp.next;
        }

        if(temp != null){
            nuevoNodo.next = temp.next; //Conectar el nuevo nodo al siguiente del nodo encontrado
            temp.next = nuevoNodo; //Conectar el nodo encontrado al nuevo nodo
            return true; //Indicar que se realizó la inserción
        }else{
            return false; //No se encontró el nodo con el valor buscado, no se puede insertar
        }
    }

    // Imprime el contenido de la lista
    public void imprimir(){
        System.out.println(toString());
    }

    //Devuelve una representación de cadena de la lista
    public String toString(){
        StringBuilder result = new StringBuilder();
        for (Node temp = top; temp != null; temp = temp.next) {
            result.append("[ ").append(temp.name).append(" ] -> ");
        }
        result.append("[X]\n");
        return result.toString();
    }

    //Elimina el primer nodo de la lista
    public void borrarPrimerNodo(){
        if (top != null) {
            top = top.next; //El siguiente nodo se convierte en el primer nodo
        }
    }

    //Elimina cualquier nodo con un valor específico
    public boolean borrarCualquierNodo(String buscado){
        if (top == null){
            return false; //La lista está vacía, no se puede borrar
        }

        if(top.name.equals(buscado)){
            top = top.next; //El siguiente nodo se convierte en el primer nodo
            return true; //Se encontró y borró el nodo
        }

        Node temp = top;
        while(temp.next != null && !temp.next.name.equals(buscado)){
            temp = temp.next;
        }

        if(temp.next != null){
            temp.next = temp.next.next; //Saltar el nodo a borrar
            return true; //Se encontró y borró el nodo
        } else {
            return false; //No se encontró el nodo con el valor buscado, no se puede borrar
        }
    }

    //Busca un nodo por su valor y devuelve una referencia a él
    public Node buscarPorValor(String valor){
        Node temp = top;
        while(temp != null && !temp.name.equals(valor)){
            temp = temp.next;
        }
        return temp; //Devuelve null si no se encontró el nodo
    }

    //Intercambia un nodo por otro buscado
    public boolean intercambiarNodo(String nombre, String buscado){
        Node nuevoNodo = new Node();
        nuevoNodo.name = nombre;

        Node tempAnterior = null;
        Node temp = top;

        while(temp != null && !temp.name.equals(buscado)){
            tempAnterior = temp;
            temp = temp.next;
        }

        if(temp != null) {
            nuevoNodo.next = temp.next; //Conectar el nuevo nodo al siguiente del nodo encontrado
            temp.next = nuevoNodo; //Conectar el nodo encontrado al nuevo nodo

            //Si tempAnterior es null, el nodo buscado es el primer nodo
            if(tempAnterior != null){
                tempAnterior.next = nuevoNodo; //Conectar el nodo anterior al nuevo nodo
            }else{
                top = nuevoNodo; //El nuevo nodo se convierte en el primer nodo
            }

            return true; //Indicar que se realizó la inserción
        }else{
            System.out.println("Nodo con valor '" + buscado + "' no encontrado.");
            return false; //No se encontró el nodo con el valor buscado, no se puede insertar
        }
    }

    //Inserta un nuevo nodo después de un nodo con un valor específico
    public boolean insertarDespues(String nombre, String buscado){
        Node nuevoNodo = new Node();
        nuevoNodo.name = nombre;

        Node temp = top;

        while(temp != null && !temp.name.equals(buscado)){
            temp = temp.next;
        }

        if(temp != null){
            nuevoNodo.next = temp.next; //Conecta el nuevo nodo al siguiente del nodo encontrado
            temp.next = nuevoNodo; //Conecta el nodo encontrado al nuevo nodo
            return true; //Indicar que se realizó la inserción
        }else{
            System.out.println("Nodo con clave '" + buscado + "' no encontrado.");
            return false; //No se encontró el nodo con el valor buscado, no se puede insertar
        }
    }
}
