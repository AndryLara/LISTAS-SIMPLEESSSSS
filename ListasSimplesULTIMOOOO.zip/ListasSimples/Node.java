//clase autorreferenciada
public class Node {
	String name; //campo de datos
    Node next;   //campo enlace
}